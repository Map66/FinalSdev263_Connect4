package com.example.connect_4

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast

private var scorePlayer = 0
private var scoreComputer = 0

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setText(intent.getIntExtra("Vic", 0))

    }
    fun go2secondActivity(view : View) {
        var intent = Intent(this,Board::class.java)
        intent.putExtra("Player", scorePlayer)
        intent.putExtra("Computer", scoreComputer)
        startActivity(intent)
    }
    fun optionBtn(view : View){
        var intent = Intent(this,Setting::class.java)
        startActivity(intent)
    }
    fun helpBtn(view : View){
        var intent = Intent(this,Help::class.java)
        startActivity(intent)
    }
    private fun setText(Vic: Int) {
        val player_score : TextView = findViewById(R.id.Player_Score)
        val computer_score : TextView = findViewById(R.id.Computer_Score)
        when (Vic) {
            1 -> scorePlayer += 1
            2 -> scoreComputer += 1
            else -> {}
        }
        player_score.text = scorePlayer.toString()
        computer_score.text = scoreComputer.toString()
        victoryCheck()
    }

    private fun  victoryCheck() {
        val PREF_NAME = "myPrefs"
        val databank : SharedPreferences = getSharedPreferences(PREF_NAME,0)

        if (databank.getString("Games","3")?.toInt() ?: Int == scorePlayer ){
            scorePlayer = 0
            scoreComputer = 0
            celebrate(1)
        } else if (databank.getString("Games","3")?.toInt() ?: Int == scoreComputer) {
            scorePlayer = 0
            scoreComputer = 0
            celebrate(2)
        }
    }

    private fun celebrate(Victor: Int) {
        if (Victor == 1) {
            Toast.makeText(this,"Congratulations", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Condolences", Toast.LENGTH_LONG).show()
        }
        setText(0)
    }
}
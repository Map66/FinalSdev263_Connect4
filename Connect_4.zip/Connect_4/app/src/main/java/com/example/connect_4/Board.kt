package com.example.connect_4

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.get
import java.util.*
import kotlin.concurrent.schedule

class Board : AppCompatActivity() {

    var board = Array(7) {Array (6) {0}}
    val PREF_NAME = "myPrefs"
    var myPref: SharedPreferences?=null
    var winner: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_board)

        val databank : SharedPreferences = getSharedPreferences(PREF_NAME, 0)
        if (databank.contains("Games")) {
           when (databank.getString("Start", "0")?.toInt()) {
               0 -> {
                   val Ran = Random()
                   val Num = Ran.nextInt(2)
                   if (Num == 1) {
                       val Ran = Random()
                       val Num = Ran.nextInt(6)
                       RanPlay(Num)
                   }
               }
               1 -> {
               }
               2-> {
                   val Ran = Random()
                   val Num = Ran.nextInt(6)
                   RanPlay(Num)
               }
           }
        } else {
            val Ran = Random()
            val Num = Ran.nextInt(2)
            if (Num == 1) {
                computerPlay()
            }
        }
        setText(intent.getIntExtra("Player", 0),intent.getIntExtra("Computer", 0))
    }

    fun go2secondActivity(view : View) {
        var intent = Intent(this,MainActivity::class.java)
        intent.putExtra("Vic",2)
        startActivity(intent)
    }

    fun btn1(view : View) { drop(0) }

    fun btn2(view : View) { drop(1) }

    fun btn3(view : View) { drop(2) }

    fun btn4(view : View) { drop(3) }

    fun btn5(view : View) { drop(4) }

    fun btn6(view : View) { drop(5) }

    fun btn7(view : View) { drop(6) }

    private fun drop(Num : Int) {
        addToArray(Num)
        if (!winner) computerPlay()
        //Log.d("Array", board.contentToString())
    }

    private fun addToArray (Num : Int) {
        for (index in 0..5) {
            if (board[Num][index] == 0) {
                board[Num][index] = 1
                placePiece(Num,index)
                break
            }
        }
    }

    private fun placePiece(Num: Int, index: Int) {
        val lay : LinearLayout = findLayout(Num)
        val place = 5 - index
        val text : TextView = lay[place] as TextView
        text.text = " O"
        text.setTextColor(Color.RED)
        testCheckPiece()
    }



    @SuppressLint("WrongViewCast")
    private fun findLayout(Num : Int): LinearLayout {
        when (Num){
            0-> return findViewById<LinearLayout>(R.id.linearLayout1)
            1-> return findViewById<LinearLayout>(R.id.linearLayout2)
            2-> return findViewById<LinearLayout>(R.id.linearLayout3)
            3-> return findViewById<LinearLayout>(R.id.linearLayout4)
            4-> return findViewById<LinearLayout>(R.id.linearLayout5)
            5-> return findViewById<LinearLayout>(R.id.linearLayout6)
            else-> return findViewById<LinearLayout>(R.id.linearLayout7)
        }
    }

    private fun computerPlay() {
        Timer(false).schedule(50) {
            val piecePlacer = PiecePlacer(board)
            piecePlacer.initialize()
            val Num = piecePlacer.chosePiece()
            for (index in 0..5) {
                if (board[Num][index] == 0) {
                    board[Num][index] = 2
                    val lay: LinearLayout = findLayout(Num)
                    val place = 5 - index
                    val text: TextView = lay[place] as TextView
                    text.text = " O"
                    text.setTextColor(Color.YELLOW)
                    testCheckPiece()
                    break
                }
                if (index == 5) {
                    val Ran = Random()
                    val Num = Ran.nextInt(6)
                        RanPlay(Num)
                }
            }
        }
    }

    private fun RanPlay(Num:Int) {
        for (index in 0..5) {
            if (board[Num][index] == 0) {
                board[Num][index] = 2
                val lay: LinearLayout = findLayout(Num)
                val place = 5 - index
                val text: TextView = lay[place] as TextView
                text.text = " O"
                text.setTextColor(Color.YELLOW)
                testCheckPiece()
                break
            }
        }
    }

    private  fun testCheckPiece() {
        for (Num in 0..6) {
            var found = false
            for (index in 0..5) {
                if (board[Num][index] == 0) {
                    continue
                } else {
                    if (checkPiece(board[Num][index], Num, index)) { Victory(board[Num][index]); found = true; break }
                }
            }
            if (found) break
        }
    }

    private fun checkPiece(player: Int, lay: Int, Num: Int) : Boolean {
        for (i in 1..3) {
            if (check(lay-i,Num-i)) {
                if (board[lay-i][Num-i] != player) break
            } else {
                break
            }
            if (i == 3) return true
        }
        for (i in 1..3) {
            if (check(lay,Num-i)) {
                if (board[lay][Num-i]!= player) break
            } else{
                break }
            if (i == 3) return true
        }
        for (i in 1..3){
            if (check(lay+i,Num-i)) {
                if (board[lay+i][Num-i]!= player) break
            } else {
                break}
            if (i == 3) return true
        }
        for (i in 1..3){
            if (check(lay+i,Num)) {
                if (board[lay+i][Num]!= player) break
            }else{
                break  }
            if (i == 3) return true
        }
        for (i in 1..3){
            if (check(lay+i,Num+i)) {
                if(board[lay+i][Num+i]!= player) break
            } else {
                break }
            if (i == 3) return true
        }
        for (i in 1..3){
            if (check(lay,Num+i)) {
                if(board[lay][Num+i]!= player) break
            } else {
                break }
            if (i == 3) return true
        }
        for (i in 1..3){
            if (check(lay-i,Num+i)) {
                if (board[lay-i][Num+i]!= player) break
            } else {
                break }
            if (i == 3) return true
        }
        for (i in 1..3){
            if (check(lay-i,Num)) {
                if (board[lay-i][Num]!= player) break
            } else {
                break }
            if (i == 3) return true
        }
        return false
    }

    private fun  check(lay: Int,Num:Int) : Boolean {
        return !(lay < 0 || Num < 0 || lay > 6 || Num > 5)
    }

    private fun Victory(player: Int) {
        winner = true
        var intent = Intent(this,MainActivity::class.java)
        intent.putExtra("Vic", player)
        startActivity(intent)
    }

    private  fun setText(player: Int, computer : Int){
        val playerText : TextView = findViewById(R.id.boardplayer)
        val computerText : TextView = findViewById(R.id.boardcomputer)
        playerText.text = player.toString()
        computerText.text = computer.toString()
    }
}






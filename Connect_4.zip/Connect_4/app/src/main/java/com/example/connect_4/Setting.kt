package com.example.connect_4

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.core.view.get

class Setting : AppCompatActivity() {
    val PREF_NAME = "myPrefs"
    var myPref:SharedPreferences?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)

        val databank : SharedPreferences = getSharedPreferences(PREF_NAME, 0)
        if (databank.contains("Games")) {
            Check(databank.getString("Games", "3"),databank.getString("Start", "0"))
        } else {
            Check("3","0")
        }


    }

    fun go2secondActivity(view : View) {
        var intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    fun save(view: View){
        myPref=getSharedPreferences(PREF_NAME,0)

        val editor : SharedPreferences.Editor=(myPref as SharedPreferences).edit()
        val NumofMatch : RadioGroup = findViewById(R.id.NumOfMatch)
        val Start : RadioGroup = findViewById(R.id.Start)

        val Match : RadioButton = findViewById(NumofMatch.checkedRadioButtonId)
        val start : RadioButton = findViewById(Start.checkedRadioButtonId)

        editor.putString("Games",Match.tag.toString())
        editor.putString("Start", start.tag.toString())

        editor.apply()
    }

    fun Check(Games: String?, Player: String?) {
        val NumofMatch : RadioGroup = findViewById(R.id.NumOfMatch)
        val Start : RadioGroup = findViewById(R.id.Start)

        val games : RadioButton = NumofMatch[Games?.toInt()!!] as RadioButton
        val start : RadioButton = Start[Player?.toInt()!! + 1] as RadioButton

        games.isChecked = true
        start.isChecked = true

    }
}
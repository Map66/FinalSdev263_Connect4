package com.example.connect_4

class PiecePlacer (var board: Array<Array<Int>>) {


    var pieces: Array<Piece>? = null

    fun initialize() {
        val hold = Array(7) {Piece(0,0)}
        for (Num in 0..6) {
            for (index in 0..5) {
                if (board[Num][index] == 0) {

                    hold[Num] = Piece(Num,index)
                    break
                }
            }
        }
        pieces = hold
    }

    fun chosePiece() : Int{
        for (Num in 0..6) {
            pieces!![Num].value = giveScore(pieces!![Num])
        }
        var placer = 0
        for (Num in 1..6) {
            if (pieces!![placer].value < pieces!![Num].value) { placer = Num}
        }
        return placer
    }

    private fun giveScore(piece: Piece): Int {
        val Num = piece.width
        val lay = piece.height
        val player = 2
        var position = 0
        var score = 0
        if (check(lay-1,Num-1)) {
            position = board[lay - 1][Num - 1]
            if (position != 0) {
                for (i in 1..3) {
                    if (check(lay - i, Num - i)) {
                        if (board[lay - i][Num - i] != position) {
                            score += givePoint(i, player == position); break
                        }
                    } else {
                        break
                    }
                    if (i == 3) score += givePoint(i, player == position)
                }
            }
        }
        if (check(lay,Num-1)) {
            position = board[lay][Num - 1]
            if (position != 0) {
                for (i in 1..3) {
                    if (check(lay, Num - i)) {
                        if (board[lay][Num - i] != position) {
                            score += givePoint(i, player == position); break
                        }
                    } else {
                        break
                    }
                    if (i == 3) score += givePoint(i, player == position)
                }
            }
        }
        if (check(lay+1,Num-1)) {
            position = board[lay + 1][Num - 1]
            if (position != 0) {
                for (i in 1..3) {
                    if (check(lay + i, Num - i)) {
                        if (board[lay + i][Num - i] != position) {
                            score += givePoint(i, player == position); break
                        }
                    } else {
                        break
                    }
                    if (i == 3) score += givePoint(i, player == position)
                }
            }
        }
        if (check(lay+1,Num)) {
            position = board[lay + 1][Num]
            if (position != 0) {
                for (i in 1..3) {
                    if (check(lay + i, Num)) {
                        if (board[lay + i][Num] != position) {
                            score += givePoint(i, player == position); break
                        }
                    } else {
                        break
                    }
                    if (i == 3) score += givePoint(i, player == position)
                }
            }
        }
        if (check(lay+1,Num+1)) {
            position = board[lay + 1][Num + 1]
            if (position != 0) {
                for (i in 1..3) {
                    if (check(lay + i, Num + i)) {
                        if (board[lay + i][Num + i] != position) {
                            score += givePoint(i, player == position); break
                        }
                    } else {
                        break
                    }
                    if (i == 3) score += givePoint(i, player == position)
                }
            }
        }
        if (check(lay,Num+1)) {
            position = board[lay][Num + 1]
            if (position != 0) {
                for (i in 1..3) {
                    if (check(lay, Num + i)) {
                        if (board[lay][Num + i] != position) {
                            score += givePoint(i, player == position); break
                        }
                    } else {
                        break
                    }
                    if (i == 3) score += givePoint(i, player == position)
                }
            }
        }
        if (check(lay-1,Num+1)) {
            position = board[lay - 1][Num + 1]
            if (position != 0) {
                for (i in 1..3) {
                    if (check(lay - i, Num + i)) {
                        if (board[lay - i][Num + i] != position) {
                            score += givePoint(i, player == position); break
                        }
                    } else {
                        break
                    }
                    if (i == 3) score += givePoint(i, player == position)
                }
            }
        }
        if (check(lay-1,Num)) {
            position = board[lay - 1][Num]
            if (position != 0) {
                for (i in 1..3) {
                    if (check(lay - i, Num)) {
                        if (board[lay - i][Num] != position) {
                            score += givePoint(i, player == position); break
                        }
                    } else {
                        break
                    }
                    if (i == 3) score += givePoint(i, player == position)
                }
            }
        }
        return score
    }

    private fun  check(lay: Int,Num:Int) : Boolean {
        return !(lay < 0 || Num < 0 || lay > 6 || Num > 5)
    }

    private fun givePoint(i : Int, p : Boolean) :Int {
        return if (p) {
            when (i) {
                1 -> 2
                2 -> 7
                3 -> 10000
                else -> 0
            }
        } else {
            when (i) {
                1 -> 3
                2 -> 21
                3 -> 1000
                else -> 0
            }
        }
    }

    inner class Piece(Height: Int, Width: Int){
        public val height = Height
        public val width = Width
        public var value = 0
    }
}

